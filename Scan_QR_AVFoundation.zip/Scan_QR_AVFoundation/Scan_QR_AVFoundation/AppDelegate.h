//
//  AppDelegate.h
//  Scan_QR_AVFoundation
//
//  Created by comfouriertech on 16/9/1.
//  Copyright © 2016年 ronghua_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

