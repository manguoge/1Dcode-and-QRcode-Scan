//
//  NSArray+descrition.h
//  Scan_QR_AVFoundation
//
//  Created by comfouriertech on 16/9/1.
//  Copyright © 2016年 ronghua_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (descrition)
-(NSString*)descriptionWithLocale:(id)locale;
@end
